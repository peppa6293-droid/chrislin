#!/usr/bin/env python3
"""Fail-closed V3 to V4 Production runtime gate. Never run in fixture mode."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import plistlib
import secrets
import shutil
import sqlite3
import stat
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

PRODUCTION_BUNDLE_ID = "com.personalfinance.console"
ACCEPTANCE_BUNDLE_ID = "com.personalfinance.console.v4acceptance"
DATABASE_NAME = "personal-finance-console.sqlite3"
PRODUCTION_MIGRATION_AUTHORIZATION = "production-v4-migration-authorization.json"
PRODUCTION_RELEASE_RECEIPT = "production-v4-release-receipt.json"
APP_NAME = "Personal Finance Console.app"
EXECUTABLE_NAME = "personal-finance-console"
APP_PATH = Path("/Applications") / APP_NAME
APP_DATA = Path.home() / "Library/Application Support" / PRODUCTION_BUNDLE_ID
DATABASE_PATH = APP_DATA / DATABASE_NAME
GATE_AUTH_PATH = APP_DATA / PRODUCTION_MIGRATION_AUTHORIZATION
RELEASE_RECEIPT_PATH = APP_DATA / PRODUCTION_RELEASE_RECEIPT
SYNTHETIC_GATE_MARKER = b"PFC_WP04R2A_GATE_SYNTHETIC_V1\n"
UNIFIED_SYNTHETIC_MARKER = b"PFC_WP04_SYNTHETIC_CUTOVER_V1\n"
UNIFIED_SYNTHETIC_BUNDLE_ID = "org.pfc.quiescence.integration"
LEGACY_EXECUTABLE_SHA256 = "0e6dcb261de20eb96fcb2f85eaa7fe78fc3cd8c72a96bee78856ac081153911f"
MANIFEST_RELATIVE_PATH = Path("Contents/Resources/runtime-compatibility.json")


class GateBlocked(RuntimeError):
    def __init__(self, reasons: list[str]):
        self.reasons = reasons
        super().__init__("Production V4 release gate blocked: " + "; ".join(reasons))


def _require_legacy_fixture_path(path: Path) -> None:
    """Retain audited helper regressions, never enable the superseded live path."""
    target = path.resolve(strict=False)
    temporary = Path(tempfile.gettempdir()).resolve()
    if target == temporary or not target.is_relative_to(temporary):
        raise GateBlocked(["QUIESCENCE_IMPLEMENTATION_NOT_PRODUCTION_AUTHORIZED: legacy mutating helpers are restricted to isolated temporary fixtures."])


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _metadata_or_none(path: Path) -> os.stat_result | None:
    """Only ENOENT means absent; every other metadata failure blocks the gate."""
    try:
        return path.lstat()
    except FileNotFoundError:
        return None
    except OSError as error:
        raise GateBlocked([f"Path metadata is unavailable for {path}: {type(error).__name__}: {error}"]) from error


def _require_single_link_regular_file(path: Path, info: os.stat_result | None = None) -> os.stat_result:
    metadata = _metadata_or_none(path) if info is None else info
    if metadata is None or not stat.S_ISREG(metadata.st_mode) or metadata.st_nlink != 1:
        raise GateBlocked([f"Path is missing or not a single-link regular file: {path}"])
    return metadata


def _nonempty_json_string(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def file_inventory(root: Path) -> dict[str, dict[str, Any]]:
    output: dict[str, dict[str, Any]] = {}
    for path in sorted(root.rglob("*")):
        if path.is_file():
            info = path.stat()
            output[str(path.relative_to(root))] = {
                "sha256": sha256_file(path),
                "mode": stat.S_IMODE(info.st_mode),
                "size": info.st_size,
            }
    return output


def read_bundle(app_path: Path) -> dict[str, Any]:
    app_metadata = _metadata_or_none(app_path)
    if app_metadata is not None and stat.S_ISLNK(app_metadata.st_mode):
        raise ValueError(f"App bundle path is a symbolic link: {app_path}")
    if app_metadata is None or not stat.S_ISDIR(app_metadata.st_mode):
        raise ValueError(f"App bundle path is missing or not a directory: {app_path}")
    bundle_root = app_path.resolve(strict=True)
    info_path = app_path / "Contents/Info.plist"
    info_metadata = _metadata_or_none(info_path)
    if info_metadata is None or not stat.S_ISREG(info_metadata.st_mode) or info_metadata.st_nlink != 1:
        raise ValueError(f"Bundle Info.plist is missing or redirected: {info_path}")
    with info_path.open("rb") as stream:
        info = plistlib.load(stream)
    if not isinstance(info, dict):
        raise ValueError(f"Bundle Info.plist must contain a dictionary: {info_path}")
    bundle_id = info.get("CFBundleIdentifier")
    if not _nonempty_json_string(bundle_id):
        raise ValueError(f"CFBundleIdentifier must be a non-empty string: {info_path}")
    executable_name = info.get("CFBundleExecutable")
    if executable_name != EXECUTABLE_NAME:
        raise ValueError(f"CFBundleExecutable must be the supported executable {EXECUTABLE_NAME!r} in {info_path}")
    executable = app_path / "Contents/MacOS" / executable_name
    executable_metadata = _metadata_or_none(executable)
    if executable_metadata is None or not stat.S_ISREG(executable_metadata.st_mode) or executable_metadata.st_nlink != 1:
        raise ValueError(f"Bundle executable is missing, redirected, or not a file: {executable}")
    resolved_executable = executable.resolve(strict=True)
    expected_executable = bundle_root / "Contents/MacOS" / EXECUTABLE_NAME
    try:
        resolved_executable.relative_to(bundle_root)
    except ValueError as error:
        raise ValueError(f"Bundle executable resolves outside its app bundle: {resolved_executable}") from error
    if resolved_executable != expected_executable:
        raise ValueError(f"Bundle executable resolved path is not canonical: {resolved_executable}")
    manifest_path = app_path / MANIFEST_RELATIVE_PATH
    manifest: dict[str, Any] | None = None
    manifest_hash: str | None = None
    manifest_metadata = _metadata_or_none(manifest_path)
    if manifest_metadata is not None:
        if not stat.S_ISREG(manifest_metadata.st_mode) or manifest_metadata.st_nlink != 1:
            raise ValueError(f"Runtime compatibility manifest is not a single-link regular file: {manifest_path}")
        resolved_manifest = manifest_path.resolve(strict=True)
        try:
            resolved_manifest.relative_to(bundle_root)
        except ValueError as error:
            raise ValueError(f"Runtime compatibility manifest resolves outside its app bundle: {resolved_manifest}") from error
        with manifest_path.open("r", encoding="utf-8") as stream:
            manifest = json.load(stream)
        manifest_hash = sha256_file(manifest_path)
    return {
        "bundle_path": str(bundle_root),
        "bundle_id": bundle_id,
        "version": info.get("CFBundleShortVersionString"),
        "executable_name": executable_name,
        "executable_path": str(resolved_executable),
        "executable_sha256": sha256_file(executable),
        "executable_mode": stat.S_IMODE(executable_metadata.st_mode),
        "manifest": manifest,
        "manifest_path": str(manifest_path.resolve()) if manifest_metadata is not None else str(manifest_path),
        "manifest_sha256": manifest_hash,
    }


def inventory_production_apps(roots: list[Path], walk: Any = os.walk) -> list[dict[str, Any]]:
    apps: list[dict[str, Any]] = []
    visited: set[str] = set()
    errors: list[dict[str, str]] = []
    for root in roots:
        root_metadata = _metadata_or_none(root)
        if root_metadata is not None and stat.S_ISLNK(root_metadata.st_mode):
            errors.append({"path": str(root), "error": "scan root is a symbolic link; inventory target is unknown"})
            continue
        if root_metadata is None and root == Path.home() / "Applications":
            continue
        if root_metadata is None:
            errors.append({"path": str(root), "error": "required scan root is missing"})
            continue
        if not stat.S_ISDIR(root_metadata.st_mode):
            errors.append({"path": str(root), "error": "scan root is not a directory"})
            continue

        def onerror(error: OSError) -> None:
            errors.append({"path": str(getattr(error, "filename", root)), "error": f"{type(error).__name__}: {error}"})

        try:
            yielded_root = False
            for current, dirs, _files in walk(root, followlinks=False, onerror=onerror):
                yielded_root = True
                for name in list(dirs):
                    child = Path(current) / name
                    if child.is_symlink():
                        errors.append({"path": str(child), "error": "symbolic directory was not traversed; contained app identities are unknown"})
                        dirs.remove(name)
                for name in list(dirs):
                    if not name.endswith(".app"):
                        continue
                    path = Path(current) / name
                    info_path = path / "Contents/Info.plist"
                    try:
                        app_info_metadata = _metadata_or_none(info_path)
                        if app_info_metadata is None or not stat.S_ISREG(app_info_metadata.st_mode) or app_info_metadata.st_nlink != 1:
                            raise ValueError("app bundle Info.plist is missing; identity is unknown")
                        with info_path.open("rb") as stream:
                            info = plistlib.load(stream)
                        if not isinstance(info, dict) or not isinstance(info.get("CFBundleIdentifier"), str):
                            raise ValueError("app bundle identity metadata is malformed")
                        if info.get("CFBundleIdentifier") != PRODUCTION_BUNDLE_ID:
                            continue
                        canonical = str(path.resolve())
                        if canonical in visited:
                            apps.append({"bundle_path": str(path), "canonical_path": canonical, "duplicate_alias": True})
                        else:
                            visited.add(canonical)
                            item = read_bundle(path)
                            item["symlink"] = path.is_symlink()
                            apps.append(item)
                    except Exception as error:  # malformed/read failures make identity unknown
                        errors.append({"path": str(info_path), "error": f"{type(error).__name__}: {error}"})
            if not yielded_root:
                errors.append({"path": str(root), "error": "directory walker returned no root entry; inventory completeness is unknown"})
        except Exception as error:
            errors.append({"path": str(root), "error": f"{type(error).__name__}: {error}"})
    if errors:
        raise GateBlocked([f"App inventory incomplete at {item['path']}: {item['error']}" for item in errors])
    return apps


def _collect_production_processes(runner: Any = subprocess.run, known_apps: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    if sys.platform != "darwin":
        raise GateBlocked(["Process and bundle inventory is supported only on macOS."])
    try:
        result = runner(["/bin/ps", "-axo", "pid=,comm=,args="], capture_output=True, text=True)
    except Exception as error:
        raise GateBlocked([f"Process snapshot is unknown: {type(error).__name__}: {error}"]) from error
    if result.returncode != 0:
        raise GateBlocked([f"Process snapshot failed (exit {result.returncode}): {result.stderr.strip()}"])
    if not result.stdout.strip():
        raise GateBlocked(["Process snapshot is empty; completeness is unknown."])
    matches: list[dict[str, Any]] = []
    seen_pids: set[int] = set()
    expected_executables = {str(Path(item["executable_path"]).resolve()) for item in (known_apps or []) if item.get("executable_path")}
    expected_db_names = {DATABASE_NAME, DATABASE_NAME + "-wal", DATABASE_NAME + "-shm", DATABASE_NAME + "-journal"}
    for line in result.stdout.splitlines():
        parts = line.strip().split(None, 2)
        if not parts:
            raise GateBlocked(["Process snapshot contains an empty row; completeness is unknown."])
        try:
            pid = int(parts[0])
        except ValueError as error:
            raise GateBlocked([f"Process snapshot contains an invalid PID row: {line!r}"]) from error
        if pid <= 0 or pid in seen_pids or len(parts) != 3 or not parts[1].strip() or not parts[2].strip():
            raise GateBlocked([f"Process snapshot row is incomplete or duplicated: {line!r}"])
        seen_pids.add(pid)
        comm, args = parts[1], parts[2]
        try:
            text_opened = runner(["/usr/sbin/lsof", "-a", "-p", str(pid), "-d", "txt", "-Fpn"], capture_output=True, text=True)
        except Exception as error:
            raise GateBlocked([f"Process {pid} inspection is unknown: {type(error).__name__}: {error}"]) from error
        if text_opened.returncode != 0:
            raise GateBlocked([f"Process {pid} executable inspection failed (exit {text_opened.returncode}): {text_opened.stderr.strip()}"])
        executable_paths = _parse_lsof_paths(text_opened.stdout, pid, "executable")
        distinct_executable_paths = {str(path.resolve()) for path in executable_paths}
        if len(distinct_executable_paths) != 1:
            raise GateBlocked([f"Process {pid} executable path is ambiguous."])
        if not executable_paths:
            raise GateBlocked([f"Process {pid} executable identity is unknown; no text executable path was returned."])
        executable = executable_paths[0]
        try:
            opened = runner(["/usr/sbin/lsof", "-a", "-p", str(pid), "-Fpn"], capture_output=True, text=True)
        except Exception as error:
            raise GateBlocked([f"Process {pid} open-file inspection is unknown: {type(error).__name__}: {error}"]) from error
        if opened.returncode != 0:
            raise GateBlocked([f"Process {pid} open-file inspection failed (exit {opened.returncode}): {opened.stderr.strip()}"])
        paths = _parse_lsof_paths(opened.stdout, pid, "open-file")
        has_db_handle = any(path.name in expected_db_names and path.parent == DATABASE_PATH.parent for path in paths)
        bundle_path: Path | None = None
        bundle_id: str | None = None
        parent = executable.parent
        while parent != parent.parent:
            if parent.suffix == ".app":
                bundle_path = parent
                try:
                    with (parent / "Contents/Info.plist").open("rb") as stream:
                        bundle_info = plistlib.load(stream)
                    if not isinstance(bundle_info, dict) or not isinstance(bundle_info.get("CFBundleIdentifier"), str) or not bundle_info["CFBundleIdentifier"].strip():
                        raise ValueError("app bundle CFBundleIdentifier is missing or not a non-empty string")
                    bundle_id = bundle_info["CFBundleIdentifier"]
                except Exception as error:
                    raise GateBlocked([f"Process {pid} executable bundle metadata is unknown: {type(error).__name__}: {error}"]) from error
                break
            parent = parent.parent
        if not executable.is_file():
            raise GateBlocked([f"Process {pid} executable path does not exist or is not a file: {executable}"])
        try:
            digest = sha256_file(executable)
        except OSError as error:
            raise GateBlocked([f"Process {pid} executable cannot be hashed: {type(error).__name__}: {error}"]) from error
        if bundle_id == PRODUCTION_BUNDLE_ID or str(executable.resolve()) in expected_executables or has_db_handle or digest == LEGACY_EXECUTABLE_SHA256:
            matches.append({"pid": pid,"executable_path": str(executable),"executable_sha256": digest,"bundle_path": str(bundle_path) if bundle_path else None,"bundle_id": bundle_id,"ps_comm": comm,"database_handle": has_db_handle})
    return matches


def _parse_lsof_paths(output: str, pid: int, label: str) -> list[Path]:
    lines = [line for line in output.splitlines() if line]
    if not lines:
        raise GateBlocked([f"Process {pid} {label} lsof result is empty."])
    pid_fields: list[int] = []
    paths: list[Path] = []
    for line in lines:
        if line.startswith("p") and line[1:].isdigit():
            pid_fields.append(int(line[1:]))
        elif line.startswith("n") and line[1:].strip():
            paths.append(Path(line[1:]))
        else:
            raise GateBlocked([f"Process {pid} {label} lsof field is malformed: {line!r}"])
    if pid_fields != [pid] or not paths:
        raise GateBlocked([f"Process {pid} {label} lsof result lacks complete PID/path fields."])
    return paths


def inventory_production_processes(runner: Any = subprocess.run, known_apps: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    try:
        processes = _collect_production_processes(runner, known_apps)
        return {"complete": True, "processes": processes, "diagnostics": []}
    except Exception as error:
        diagnostic = f"{type(error).__name__}: {error}"
        return {"complete": False, "processes": None, "diagnostics": [diagnostic]}


def inspect_database(path: Path) -> dict[str, Any]:
    _require_single_link_regular_file(path)
    sidecars = []
    for suffix in ("-wal", "-shm", "-journal"):
        sidecar = Path(str(path) + suffix)
        info = _metadata_or_none(sidecar)
        if info is not None:
            sidecars.append(str(sidecar))
    if sidecars:
        raise GateBlocked(["SQLite sidecar exists; database open is prohibited until a separately authorized recovery decision."])
    uri = f"file:{path.resolve()}?mode=ro"
    connection = sqlite3.connect(uri, uri=True)
    try:
        user_version = int(connection.execute("PRAGMA user_version").fetchone()[0])
        has_migrations = connection.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='schema_migrations'"
        ).fetchone() is not None
        migration_version = (
            int(connection.execute("SELECT COALESCE(MAX(version),0) FROM schema_migrations").fetchone()[0])
            if has_migrations
            else 0
        )
        integrity = [row[0] for row in connection.execute("PRAGMA integrity_check")]
        foreign_keys = [list(row) for row in connection.execute("PRAGMA foreign_key_check")]
        return {
            "path": str(path.resolve()),
            "sha256": sha256_file(path),
            "user_version": user_version,
            "migration_version": migration_version,
            "integrity": integrity,
            "foreign_key_violations": foreign_keys,
            "sidecars": sidecars,
        }
    finally:
        connection.close()


def validate_manifest(bundle: dict[str, Any], *, expected_bundle_id: str = PRODUCTION_BUNDLE_ID) -> list[str]:
    manifest = bundle.get("manifest")
    if not isinstance(manifest, dict):
        return ["Candidate has no embedded runtime compatibility manifest."]
    errors: list[str] = []
    expected = {
        "manifestFormatVersion": 1,
        "runtimeGeneration": 4,
        "maxSupportedSchemaVersion": 4,
        "bundleId": expected_bundle_id,
        "executable": f"Contents/MacOS/{bundle.get('executable_name')}",
    }
    for key, value in expected.items():
        if manifest.get(key) != value:
            errors.append(f"Candidate compatibility manifest field {key} must be {value!r}.")
    if bundle.get("executable_name") != EXECUTABLE_NAME or manifest.get("executable") != f"Contents/MacOS/{EXECUTABLE_NAME}":
        errors.append("Candidate executable identity/path is not the fixed Production executable.")
    minimum = manifest.get("minSupportedSchemaVersion")
    if not isinstance(minimum, int) or minimum < 1 or minimum > 3:
        errors.append("Candidate compatibility manifest must declare support for schema V3 and migration from an earlier version.")
    return errors


def validate_preflight(facts: dict[str, Any], *, synthetic_fixture_root: Path | None = None,
                       unified_r2b: bool = False) -> list[str]:
    errors: list[str] = []
    if facts.get("platform") != "darwin":
        errors.append("Production release gate requires macOS.")
    processes = facts.get("running_production_processes")
    if not isinstance(processes, list):
        errors.append("Production process inventory is unknown.")
    elif processes:
        errors.append("A Production-identity process or unknown matching executable is still running.")

    expected_app = Path(str(facts.get("expected_installed_app", "")))
    if synthetic_fixture_root is None:
        required_app_path = APP_PATH.resolve()
        required_database_path = DATABASE_PATH.resolve()
    elif unified_r2b:
        fixture_root = synthetic_fixture_root.resolve()
        required_app_path = (fixture_root / "managed/install/Installed.app").resolve()
        required_database_path = (fixture_root / DATABASE_NAME).resolve()
    else:
        fixture_root = synthetic_fixture_root.resolve()
        protected_paths = [Path("/Applications").resolve(), APP_DATA.resolve()]
        if any(fixture_root == protected or protected in fixture_root.parents or fixture_root in protected.parents for protected in protected_paths):
            errors.append("Synthetic fixture root overlaps a protected Production path.")
        required_app_path = (fixture_root / "Applications" / APP_NAME).resolve()
        required_database_path = (fixture_root / "Library/Application Support" / PRODUCTION_BUNDLE_ID / DATABASE_NAME).resolve()
    if expected_app.resolve() != required_app_path:
        errors.append("Production candidate app path does not match the fixed or synthetic-contract location.")
    apps = facts.get("production_apps")
    if not isinstance(apps, list):
        errors.append("Installed Production bundle inventory is unknown.")
        apps = []
    if facts.get("app_inventory_complete") is not True:
        errors.append("Installed Production bundle inventory is incomplete or unknown.")
    if facts.get("process_inventory_complete") is not True:
        errors.append("Production process inventory is incomplete or unknown.")
    process_inventory = facts.get("process_inventory")
    if not isinstance(process_inventory, dict) or process_inventory.get("complete") is not True or not isinstance(process_inventory.get("processes"), list):
        errors.append("Production process inventory completeness facts are missing or unknown.")
    elif process_inventory.get("processes") != processes:
        errors.append("Production process inventory facts do not match the process list being evaluated.")
    if len(apps) != 1:
        errors.append("Normal launch locations must contain exactly one Production-identity app bundle.")
    candidate = facts.get("candidate")
    if not isinstance(candidate, dict):
        errors.append("Installed candidate facts are unknown.")
        candidate = {}
    else:
        errors.extend(validate_manifest(candidate, expected_bundle_id=UNIFIED_SYNTHETIC_BUNDLE_ID if unified_r2b else PRODUCTION_BUNDLE_ID))
        executable_mode = candidate.get("executable_mode")
        if not isinstance(executable_mode, int) or isinstance(executable_mode, bool):
            errors.append("Candidate executable mode is missing or invalid.")
        elif not (executable_mode & 0o111):
            errors.append("Candidate executable has no execute permission.")
        try:
            candidate_bundle = Path(candidate["bundle_path"]).resolve(strict=True)
            candidate_executable = Path(candidate["executable_path"]).resolve(strict=True)
            expected_executable = candidate_bundle / "Contents/MacOS" / EXECUTABLE_NAME
            candidate_executable.relative_to(candidate_bundle)
            if candidate_executable != expected_executable or not candidate_executable.is_file():
                errors.append("Candidate executable canonical path does not match the executable inside its bundle.")
        except (KeyError, OSError, TypeError, ValueError) as error:
            errors.append(f"Candidate executable path is missing, invalid, or outside its bundle: {type(error).__name__}: {error}")
    if len(apps) == 1:
        installed = apps[0]
        if installed.get("unreadable") or installed.get("duplicate_alias") or installed.get("symlink"):
            errors.append("Installed Production bundle has unknown metadata or a path alias.")
        if Path(str(installed.get("bundle_path", ""))) != expected_app.resolve():
            errors.append("A Production-identity app exists outside the approved /Applications installation path.")
        expected_identity = UNIFIED_SYNTHETIC_BUNDLE_ID if unified_r2b else PRODUCTION_BUNDLE_ID
        if installed.get("bundle_id") != expected_identity:
            errors.append("Installed bundle ID is not the Production identity.")
        if installed.get("executable_sha256") == LEGACY_EXECUTABLE_SHA256:
            errors.append("Known legacy V3 Production runtime is still installed.")
        if candidate and installed.get("executable_sha256") != candidate.get("executable_sha256"):
            errors.append("Installed Production executable does not match the inspected candidate.")
    if candidate:
        expected_identity = UNIFIED_SYNTHETIC_BUNDLE_ID if unified_r2b else PRODUCTION_BUNDLE_ID
        if candidate.get("bundle_id") != expected_identity:
            errors.append(f"Candidate bundle ID must be {expected_identity}.")
        if candidate.get("bundle_id") == ACCEPTANCE_BUNDLE_ID:
            errors.append("Acceptance bundle ID cannot be used as a Production candidate.")
        if Path(str(candidate.get("bundle_path", ""))) != expected_app.resolve():
            errors.append("Candidate must be installed at /Applications/Personal Finance Console.app.")
        if Path(str(candidate.get("bundle_path", ""))).resolve() != required_app_path:
            errors.append("Candidate bundle path does not match the fixed or synthetic-contract location.")

    approval = facts.get("candidate_approval")
    migration_authorization = facts.get("migration_authorization")
    expected_approval_status = "OWNER_APPROVED_SYNTHETIC_R2B_CANDIDATE" if unified_r2b else "OWNER_APPROVED_V4_PRODUCTION_CANDIDATE"
    expected_authorization_status = "OWNER_AUTHORIZED_SYNTHETIC_R2B_MIGRATION" if unified_r2b else "OWNER_AUTHORIZED_PRODUCTION_V4_MIGRATION"
    expected_bundle_id = UNIFIED_SYNTHETIC_BUNDLE_ID if unified_r2b else PRODUCTION_BUNDLE_ID
    if not isinstance(approval, dict):
        errors.append("Approved candidate record is missing or unreadable.")
    else:
        if approval.get("status") != expected_approval_status:
            errors.append("Candidate approval status does not match the selected authorization domain.")
        if not _nonempty_json_string(approval.get("authorizationId")):
            errors.append("Candidate approval ID is missing.")
        if candidate and approval.get("candidateExecutableSha256") != candidate.get("executable_sha256"):
            errors.append("Candidate executable hash does not match the Owner-approved hash.")
        if candidate and approval.get("compatibilityManifestSha256") != candidate.get("manifest_sha256"):
            errors.append("Candidate compatibility manifest hash does not match the Owner-approved hash.")
        if approval.get("bundleId") != expected_bundle_id or approval.get("maxSupportedSchemaVersion") != 4:
            errors.append("Candidate approval must name the fixed selected bundle and Schema V4.")

    database = facts.get("production_database")
    if not isinstance(database, dict):
        errors.append("Production database facts are unknown.")
        database = {}
    if Path(str(database.get("path", ""))) != Path(str(facts.get("expected_database_path", ""))).resolve():
        if not unified_r2b:
            errors.append("Production database path does not match the authorized identity and basename.")
    if Path(str(database.get("path", ""))).resolve() != required_database_path:
        errors.append("Production database path does not match the fixed or synthetic-contract location.")
    if Path(str(database.get("path", ""))).name != DATABASE_NAME:
        errors.append("Production database basename does not match the fixed Production SQLite identity.")
    if database.get("user_version") != 3 or database.get("migration_version") != 3:
        errors.append("Production migration source must be consistent Schema V3.")
    if database.get("integrity") != ["ok"] or database.get("foreign_key_violations") != []:
        errors.append("Production database integrity or foreign-key preflight failed.")
    if database.get("sidecars") != []:
        errors.append("Production SQLite state is not quiescent; WAL/SHM/journal sidecars must be absent.")
    if facts.get("sidecars_absent") is not True:
        errors.append("Production sidecar absence was not established.")

    backup = facts.get("backup")
    if not isinstance(backup, dict) or not backup.get("exists"):
        errors.append("Byte-for-byte pre-migration Production backup is missing.")
    elif database and backup.get("sha256") != database.get("sha256"):
        errors.append("Production backup hash does not match the pre-migration database hash.")
    if not isinstance(migration_authorization, dict):
        errors.append("Separate Production V4 migration authorization is missing or unreadable.")
    else:
        if migration_authorization.get("status") != expected_authorization_status:
            errors.append("A separate explicit migration authorization for the selected domain is required.")
    if migration_authorization and backup and migration_authorization.get("productionDbPreMigrationSha256") != database.get("sha256"):
        errors.append("Migration approval is not bound to the verified Production pre-migration hash.")
    if migration_authorization and backup and Path(str(migration_authorization.get("backupPath", ""))).resolve() != Path(str(backup.get("path", ""))).resolve():
        errors.append("Verified backup path does not match the migration approval.")
    if migration_authorization and candidate and migration_authorization.get("candidateExecutableSha256") != candidate.get("executable_sha256"):
        errors.append("Migration approval candidate hash does not match the installed candidate.")
    if not isinstance(migration_authorization, dict) or not _nonempty_json_string(migration_authorization.get("authorizationId")):
        errors.append("Production migration authorization ID is missing.")
    if backup and Path(str(backup.get("path", ""))).resolve() == Path(str(database.get("path", ""))).resolve():
        errors.append("Production byte-for-byte backup path must differ from the source database path.")
    if backup and database:
        backup_path = Path(str(backup.get("path", ""))).resolve()
        required_backup_root = (synthetic_fixture_root.resolve() if unified_r2b else Path(str(database.get("path", ""))).resolve().parent / "production-v4-backups")
        try:
            backup_path.relative_to(required_backup_root)
        except ValueError:
            errors.append("Production backup path must be inside the native-approved production-v4-backups directory.")
    if candidate and (candidate.get("executable_name") != EXECUTABLE_NAME or Path(str(candidate.get("executable_path", ""))).name != EXECUTABLE_NAME):
        errors.append("Candidate executable name/path is not the fixed Production executable.")
    return errors


def make_release_receipt(facts: dict[str, Any], *, synthetic_fixture_root: Path | None = None,
                         unified_r2b: bool = False) -> dict[str, Any]:
    errors = validate_preflight(facts, synthetic_fixture_root=synthetic_fixture_root, unified_r2b=unified_r2b)
    if errors:
        raise GateBlocked(errors)
    if not _nonempty_json_string(facts.get("candidate_approval_sha256")) or not _nonempty_json_string(facts.get("migration_authorization_sha256")):
        raise GateBlocked(["Exact candidate-approval and migration-authorization byte hashes are required for a release receipt."])
    candidate = facts["candidate"]
    database = facts["production_database"]
    backup = facts["backup"]
    return {
        "receiptFormatVersion": 1,
        "status": "PREFLIGHT_PASS_READY_FOR_SEPARATELY_AUTHORIZED_MIGRATION",
        "observedAtUtc": datetime.now(timezone.utc).isoformat(),
        "syntheticOnly": facts.get("synthetic_only") is True,
        "candidateApprovalSha256": facts["candidate_approval_sha256"],
        "migrationAuthorizationSha256": facts["migration_authorization_sha256"],
        "productionBundleId": UNIFIED_SYNTHETIC_BUNDLE_ID if unified_r2b else PRODUCTION_BUNDLE_ID,
        "installedAppPath": str(Path(str(facts["expected_installed_app"])).resolve()),
        "candidateExecutablePath": candidate["executable_path"],
        "candidateExecutableSha256": candidate["executable_sha256"],
        "compatibilityManifestSha256": candidate["manifest_sha256"],
        "maxSupportedSchemaVersion": candidate["manifest"]["maxSupportedSchemaVersion"],
        "sidecarsAbsent": database.get("sidecars") == [] and facts.get("sidecars_absent") is True,
        "productionDatabasePath": database["path"],
        "productionDatabasePreMigrationSha256": database["sha256"],
        "productionSchema": {
            "userVersion": database["user_version"],
            "migrationVersion": database["migration_version"],
        },
        "backupPath": str(Path(str(backup["path"])).resolve()),
        "backupSha256": backup["sha256"],
        "ownerAuthorizationId": facts["migration_authorization"].get("authorizationId"),
        "candidateApprovalId": facts["candidate_approval"].get("authorizationId"),
        "processInventory": facts.get("process_inventory"),
        "productionAppInventory": facts["production_apps"],
    }


def _load_json(path: Path, label: str) -> dict[str, Any]:
    try:
        with path.open("r", encoding="utf-8") as stream:
            value = json.load(stream)
        if not isinstance(value, dict):
            raise ValueError(f"{label} must be a JSON object.")
        return value
    except (OSError, json.JSONDecodeError) as error:
        raise GateBlocked([f"{label} is missing or unreadable: {error}"]) from error


def _load_json_snapshot(path: Path, label: str) -> tuple[dict[str, Any], str, bytes]:
    """Read one exact regular-file byte vector and bind its identity and hash."""
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0)
    try:
        fd = os.open(path, flags)
        with os.fdopen(fd, "rb") as stream:
            before = os.fstat(stream.fileno())
            if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
                raise GateBlocked([f"{label} must be a single-link regular file."])
            data = stream.read(1_048_577)
            after = os.fstat(stream.fileno())
        current = path.lstat()
        identity = lambda item: (item.st_dev, item.st_ino, item.st_size, item.st_nlink, item.st_mtime_ns)
        if len(data) > 1_048_576 or identity(before) != identity(after) or identity(before) != identity(current):
            raise GateBlocked([f"{label} changed while being read or exceeds the size limit."])
        value = json.loads(data)
        if not isinstance(value, dict):
            raise ValueError("expected JSON object")
        return value, hashlib.sha256(data).hexdigest(), data
    except GateBlocked:
        raise
    except (OSError, json.JSONDecodeError, ValueError) as error:
        raise GateBlocked([f"{label} is missing, unsafe, or unreadable: {type(error).__name__}: {error}"]) from error


def _persist_receipt(path: Path, receipt: dict[str, Any], *, create: bool) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if create:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(receipt, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        directory_fd = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
        return
    temporary = path.with_name(path.name + f".tmp-{os.getpid()}")
    with temporary.open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def collect_real_facts(candidate_approval_path: Path, migration_authorization_path: Path) -> dict[str, Any]:
    candidate_approval, candidate_approval_sha256, _ = _load_json_snapshot(candidate_approval_path, "Candidate approval")
    migration_authorization, migration_authorization_sha256, _ = _load_json_snapshot(migration_authorization_path, "Production migration authorization")
    if candidate_approval.get("syntheticOnly") is True or migration_authorization.get("syntheticOnly") is True:
        raise GateBlocked(["Synthetic authorization artifacts are not valid in Production mode."])
    roots = [Path("/Applications"), Path.home() / "Applications"]
    apps = inventory_production_apps(roots)
    if _metadata_or_none(APP_PATH) is None:
        candidate: dict[str, Any] = {}
    else:
        candidate = read_bundle(APP_PATH)
    database = inspect_database(DATABASE_PATH)
    approval_backup_path = Path(str(migration_authorization.get("backupPath", "")))
    backup_metadata = _metadata_or_none(approval_backup_path)
    backup_exists = backup_metadata is not None and stat.S_ISREG(backup_metadata.st_mode) and backup_metadata.st_nlink == 1
    backup = {
        "path": str(approval_backup_path.resolve()) if backup_metadata is not None else str(approval_backup_path),
        "exists": backup_exists,
        "sha256": sha256_file(approval_backup_path) if backup_exists else None,
    }
    process_inventory = inventory_production_processes(known_apps=apps)
    processes = process_inventory["processes"] if process_inventory["complete"] else None
    database_sidecars_absent = database.get("sidecars") == []
    return {
        "platform": sys.platform,
        "expected_installed_app": str(APP_PATH),
        "expected_database_path": str(DATABASE_PATH),
        "running_production_processes": processes,
        "process_inventory": process_inventory,
        "process_inventory_complete": process_inventory["complete"],
        "app_inventory_complete": True,
        "sidecars_absent": database_sidecars_absent,
        "production_apps": apps,
        "candidate": candidate,
        "candidate_approval": candidate_approval,
        "migration_authorization": migration_authorization,
        "candidate_approval_sha256": candidate_approval_sha256,
        "migration_authorization_sha256": migration_authorization_sha256,
        "synthetic_only": False,
        "production_database": database,
        "backup": backup,
    }


def _validate_synthetic_gate_root(root: Path, *, unified_r2b: bool = False) -> Path:
    try:
        raw = root
        resolved = raw.resolve(strict=True)
        temporary = Path(tempfile.gettempdir()).resolve(strict=True)
        if raw != resolved or resolved == temporary or not resolved.is_relative_to(temporary):
            raise GateBlocked(["Synthetic gate root must be a canonical child of the OS temporary directory."])
        protected = [Path("/Applications").resolve(), APP_DATA.resolve()]
        if any(resolved == item or resolved in item.parents or item in resolved.parents for item in protected):
            raise GateBlocked(["Synthetic gate root overlaps a Production-protected path."])
        marker = resolved / "SYNTHETIC_ONLY"
        _require_single_link_regular_file(marker)
        expected_marker = UNIFIED_SYNTHETIC_MARKER if unified_r2b else SYNTHETIC_GATE_MARKER
        if marker.read_bytes() != expected_marker:
            raise GateBlocked(["Synthetic gate marker is missing or invalid."])
        return resolved
    except GateBlocked:
        raise
    except OSError as error:
        raise GateBlocked([f"Synthetic gate root is unavailable: {error}"]) from error


def collect_synthetic_facts(
    root: Path,
    candidate_approval_path: Path,
    migration_authorization_path: Path,
    *, unified_r2b: bool = False,
) -> dict[str, Any]:
    """Use the common release-gate checks against one explicitly marked temp namespace."""
    root = _validate_synthetic_gate_root(root, unified_r2b=unified_r2b)
    approval_path = candidate_approval_path.resolve(strict=True)
    authorization_path = migration_authorization_path.resolve(strict=True)
    for label, path in (("Candidate approval", approval_path), ("Migration authorization", authorization_path)):
        try:
            path.relative_to(root)
        except ValueError as error:
            raise GateBlocked([f"Synthetic {label.lower()} must be inside the marked synthetic root."]) from error
    candidate_approval, candidate_approval_sha256, _ = _load_json_snapshot(approval_path, "Synthetic candidate approval")
    migration_authorization, migration_authorization_sha256, _ = _load_json_snapshot(authorization_path, "Synthetic migration authorization")
    if candidate_approval.get("syntheticOnly") is not True or migration_authorization.get("syntheticOnly") is not True:
        raise GateBlocked(["Production authorization artifacts are not valid in synthetic mode."])

    if unified_r2b:
        app_path = (root / "managed/install/Installed.app").resolve()
        app_data = root
        database_path = root / DATABASE_NAME
        if any((root / name).exists() or (root / name).is_symlink() for name in ("authorization.json", "permit.json", "consumed.json")):
            raise GateBlocked(["Unified Gate-owned root contains a standalone quiescence authority artifact."])
        contract = _load_json(root / "managed-contract.json", "Gate-owned managed contract")
        if contract.get("synthetic_only") is not True or contract.get("root") != str(root):
            raise GateBlocked(["Gate-owned managed contract is missing or bound to another root."])
    else:
        app_path = (root / "Applications" / APP_NAME).resolve()
        app_data = (root / "Library" / "Application Support" / PRODUCTION_BUNDLE_ID).resolve()
        database_path = app_data / DATABASE_NAME
    candidate = read_bundle(app_path)
    database = inspect_database(database_path)
    backup_path = Path(str(migration_authorization.get("backupPath", ""))).resolve(strict=True)
    try:
        backup_path.relative_to(root if unified_r2b else app_data / "production-v4-backups")
    except ValueError as error:
        raise GateBlocked(["Synthetic backup must be inside the synthetic root's fixed backup directory."]) from error
    backup_info = _require_single_link_regular_file(backup_path)
    backup = {"path": str(backup_path), "exists": True, "sha256": sha256_file(backup_path),
              "size": backup_info.st_size}
    process_inventory = {"complete": True, "processes": [], "diagnostics": []}
    return {
        "platform": "darwin",
        "expected_installed_app": str(app_path),
        "expected_database_path": str(database_path),
        "running_production_processes": [],
        "process_inventory": process_inventory,
        "process_inventory_complete": True,
        "app_inventory_complete": True,
        "sidecars_absent": database.get("sidecars") == [],
        "production_apps": [candidate],
        "candidate": candidate,
        "candidate_approval": candidate_approval,
        "migration_authorization": migration_authorization,
        "candidate_approval_sha256": candidate_approval_sha256,
        "migration_authorization_sha256": migration_authorization_sha256,
        "synthetic_only": True,
        "production_database": database,
        "backup": backup,
        "synthetic_root": str(root),
        "native_consumer_executable": candidate["executable_path"],
        "unified_r2b": unified_r2b,
    }


def write_migration_permit(
    receipt: dict[str, Any],
    approval: dict[str, Any],
    permit_path: Path = GATE_AUTH_PATH,
    *,
    synthetic_fixture_root: Path | None = None,
    unified_r2b: bool = False,
) -> tuple[Path, str]:
    synthetic_only = receipt.get("syntheticOnly") is True
    if synthetic_only:
        if synthetic_fixture_root is None:
            _require_legacy_fixture_path(permit_path)
        else:
            root = _validate_synthetic_gate_root(synthetic_fixture_root, unified_r2b=unified_r2b)
            if unified_r2b and any(_metadata_or_none(root / name) is not None for name in
                    ("gate-permit.claimed", "gate-permit.claimed.json", "consumed-ledger.json")):
                raise GateBlocked(["Unified synthetic permit was already claimed; replay is refused."])
            expected = root / "gate-permit.json" if unified_r2b else root / "Library" / "Application Support" / PRODUCTION_BUNDLE_ID / PRODUCTION_MIGRATION_AUTHORIZATION
            if permit_path.resolve(strict=False) != expected.resolve(strict=False):
                raise GateBlocked(["Synthetic permit path does not match the fixed synthetic namespace path."])
    elif permit_path.resolve(strict=False) != GATE_AUTH_PATH.resolve(strict=False):
        raise GateBlocked(["Production permit path must be the fixed native-approved application-data path."])
    if receipt.get("sidecarsAbsent") is not True:
        raise GateBlocked(["SQLite sidecar absence was not bound into the release receipt."])
    if not receipt.get("releaseReceiptSha256") or not receipt.get("migrationAuthorizationSha256"):
        raise GateBlocked(["Permit requires persisted release-receipt and exact authorization byte hashes."])
    nonce = secrets.token_urlsafe(32)
    now = int(time.time())
    permit = {
        **receipt,
        "receiptFormatVersion": 1,
        "status": "ONE_TIME_PRODUCTION_V4_MIGRATION_AUTHORIZATION",
        "nonce": nonce,
        "issuedAtUnix": now,
        "expiresAtUnix": now + 120,
        "ownerAuthorizationId": approval.get("authorizationId"),
    }
    permit_path.parent.mkdir(parents=True, exist_ok=True)
    if _metadata_or_none(permit_path) is not None:
        raise GateBlocked(["An unconsumed Production migration authorization already exists."])
    temporary = permit_path.with_suffix(".tmp")
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        json.dump(permit, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, permit_path)
    directory_fd = os.open(permit_path.parent, os.O_RDONLY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)
    return permit_path, nonce


def run_gate(
    mode: str,
    candidate_approval_path: Path,
    migration_authorization_path: Path,
    receipt_path: Path | None = None,
    *,
    synthetic_fixture_root: Path | None = None,
    synthetic_mode: str = "legacy-component",
) -> dict[str, Any]:
    if mode not in {"preflight", "migrate"}:
        raise ValueError(f"Unsupported gate mode: {mode}")
    if sys.platform != "darwin":
        raise GateBlocked(["Production release gate requires macOS."])
    synthetic_only = synthetic_fixture_root is not None
    unified_r2b = synthetic_only and synthetic_mode == "unified-r2b"
    if synthetic_only and synthetic_mode not in {"legacy-component", "unified-r2b"}:
        raise GateBlocked(["Synthetic mode must be explicitly legacy-component or unified-r2b."])
    if receipt_path is None:
        receipt_path = (
            _validate_synthetic_gate_root(synthetic_fixture_root, unified_r2b=True) / "release-receipt.json"
            if unified_r2b else
            _validate_synthetic_gate_root(synthetic_fixture_root) / "Library" / "Application Support" /
            PRODUCTION_BUNDLE_ID / PRODUCTION_RELEASE_RECEIPT
            if synthetic_only else RELEASE_RECEIPT_PATH
        )
    try:
        migration_authorization, migration_authorization_sha256, _ = _load_json_snapshot(migration_authorization_path, "Production migration authorization")
    except GateBlocked as error:
        raise GateBlocked([f"REFUSE_NO_AUTHORIZATION: {error}"]) from error
    expected_auth_status = "OWNER_AUTHORIZED_SYNTHETIC_R2B_MIGRATION" if unified_r2b else "OWNER_AUTHORIZED_PRODUCTION_V4_MIGRATION"
    expected_approval_status = "OWNER_APPROVED_SYNTHETIC_R2B_CANDIDATE" if unified_r2b else "OWNER_APPROVED_V4_PRODUCTION_CANDIDATE"
    if migration_authorization.get("status") != expected_auth_status:
        raise GateBlocked(["REFUSE_NO_AUTHORIZATION: a separate explicit Owner Production V4 migration authorization is required."])
    candidate_approval, candidate_approval_sha256, _ = _load_json_snapshot(candidate_approval_path, "Candidate approval")
    if candidate_approval.get("status") != expected_approval_status:
        raise GateBlocked(["Candidate approval is missing or is not Owner-approved for Production V4."])
    if synthetic_only and (candidate_approval.get("syntheticOnly") is not True or migration_authorization.get("syntheticOnly") is not True):
        raise GateBlocked(["Synthetic authorization artifacts must carry syntheticOnly=true."])
    if not synthetic_only and (candidate_approval.get("syntheticOnly") is True or migration_authorization.get("syntheticOnly") is True):
        raise GateBlocked(["Authorization domain does not match the selected Production or synthetic gate mode."])
    if unified_r2b:
        root = _validate_synthetic_gate_root(synthetic_fixture_root, unified_r2b=True)
        if candidate_approval_path.resolve(strict=False) != (root / "gate-inputs/candidate-approval.json").resolve(strict=False) or \
                migration_authorization_path.resolve(strict=False) != (root / "gate-inputs/migration-authorization.json").resolve(strict=False):
            raise GateBlocked(["Unified synthetic authorization inputs must use their fixed in-root paths."])
    facts = (
        collect_synthetic_facts(synthetic_fixture_root, candidate_approval_path, migration_authorization_path, unified_r2b=unified_r2b)
        if synthetic_only else collect_real_facts(candidate_approval_path, migration_authorization_path)
    )
    if facts["candidate_approval_sha256"] != candidate_approval_sha256 or facts["migration_authorization_sha256"] != migration_authorization_sha256:
        raise GateBlocked(["Authorization byte identity changed between domain validation and fact collection."])
    receipt = make_release_receipt(facts, synthetic_fixture_root=synthetic_fixture_root, unified_r2b=unified_r2b)
    receipt["releaseReceiptPath"] = str(receipt_path.resolve(strict=False))
    if mode == "preflight":
        _persist_receipt(receipt_path, receipt, create=True)
        return receipt
    persisted_receipt, persisted_receipt_sha256, _ = _load_json_snapshot(receipt_path, "Persisted release receipt")
    if persisted_receipt.get("status") != "PREFLIGHT_PASS_READY_FOR_SEPARATELY_AUTHORIZED_MIGRATION":
        raise GateBlocked(["Migrate requires a persisted successful preflight receipt."])
    compare_fields = (
        "syntheticOnly", "candidateApprovalSha256", "migrationAuthorizationSha256", "productionBundleId",
        "installedAppPath", "candidateExecutablePath", "candidateExecutableSha256", "compatibilityManifestSha256",
        "productionDatabasePath", "productionDatabasePreMigrationSha256", "productionSchema", "backupPath",
        "backupSha256", "sidecarsAbsent", "ownerAuthorizationId", "candidateApprovalId", "releaseReceiptPath",
    )
    if any(persisted_receipt.get(field) != receipt.get(field) for field in compare_fields):
        raise GateBlocked(["Persisted preflight receipt no longer matches current authorization, candidate, database, or backup facts."])
    receipt["releaseReceiptSha256"] = persisted_receipt_sha256
    permit_path = (
        _validate_synthetic_gate_root(synthetic_fixture_root, unified_r2b=True) / "gate-permit.json"
        if unified_r2b else
        _validate_synthetic_gate_root(synthetic_fixture_root) / "Library" / "Application Support" /
        PRODUCTION_BUNDLE_ID / PRODUCTION_MIGRATION_AUTHORIZATION
        if synthetic_only else GATE_AUTH_PATH
    )
    try:
        permit_path, _nonce = write_migration_permit(
            receipt, migration_authorization, permit_path, synthetic_fixture_root=synthetic_fixture_root,
            unified_r2b=unified_r2b
        )
    except Exception as error:
        raise
    executable = Path(receipt["candidateExecutablePath"])
    command = (
        [str(executable), "--pfc-r2b1-unified-synthetic", str(_validate_synthetic_gate_root(synthetic_fixture_root, unified_r2b=True))]
        if unified_r2b else [str(executable), "--pfc-synthetic-gate-consume", str(_validate_synthetic_gate_root(synthetic_fixture_root))]
        if synthetic_only else [str(executable), "--pfc-internal-v4-migrate"]
    )
    try:
        child_options: dict[str, Any] = {}
        if unified_r2b:
            try:
                lease_fd = int(os.environ["PFC_QUIESCENCE_LEASE_FD"])
                lease_session = os.environ["PFC_QUIESCENCE_SESSION"]
                lease_path = os.environ["PFC_QUIESCENCE_LEASE_PATH"]
            except (KeyError, ValueError) as error:
                raise GateBlocked(["Unified native handoff requires the live C3 maintenance lease descriptor."]) from error
            if lease_fd <= 2 or lease_path != str(_validate_synthetic_gate_root(synthetic_fixture_root, unified_r2b=True) / "maintenance.lock"):
                raise GateBlocked(["Unified native handoff lease binding is invalid."])
            child_options["pass_fds"] = (lease_fd,)
            child_options["env"] = {**os.environ, "PFC_QUIESCENCE_SESSION": lease_session,
                                     "PFC_GATE_PERMIT_SHA256": sha256_file(permit_path)}
        result = subprocess.run(command, cwd=str(executable.parent), capture_output=True, text=True, timeout=120, **child_options)
    except (OSError, subprocess.TimeoutExpired) as error:
        raise GateBlocked([f"Native migration consumer did not complete; permit remains a one-time unresolved attempt: {type(error).__name__}: {error}"]) from error
    if result.returncode != 0:
        raise GateBlocked([f"Native migration consumer refused or failed (exit={result.returncode}): {result.stderr.strip() or result.stdout.strip()}"])
    try:
        native_result = json.loads(result.stdout.strip().splitlines()[-1])
    except (IndexError, json.JSONDecodeError) as error:
        raise GateBlocked(["Native migration consumer returned no valid terminal JSON result."]) from error
    expected_native_status = ("VERIFIED_HANDOFF" if unified_r2b else "AUTHORIZATION_CONSUMED_NATIVE_MIGRATION_PENDING") if synthetic_only else "V4_MIGRATION_VERIFIED_NATIVE"
    if native_result.get("event") != "gate_permit_consumed" or native_result.get("status") != expected_native_status or native_result.get("syntheticOnly") is not synthetic_only:
        raise GateBlocked(["Native migration consumer did not confirm the expected domain-specific permit/ledger boundary."])
    return {"status": "NATIVE_CONSUMER_BOUND", "receiptPath": str(receipt_path), "receiptSha256": persisted_receipt_sha256,
            "permitPath": str(permit_path), "native": native_result, "stdout": result.stdout}


def retirement_replace(
    old_app: Path,
    candidate_source: Path,
    normal_app_path: Path,
    archive_root: Path,
    authorization: dict[str, Any],
    running_processes: list[dict[str, Any]],
    production_app_inventory: list[dict[str, Any]],
    expected_old_sha256: str = LEGACY_EXECUTABLE_SHA256,
) -> dict[str, Any]:
    for path in (old_app, candidate_source, normal_app_path, archive_root):
        _require_legacy_fixture_path(path)
    if authorization.get("status") != "OWNER_AUTHORIZED_RUNTIME_REPLACEMENT":
        raise GateBlocked(["A separate Owner authorization for runtime replacement is required."])
    required_string_fields = (
        "authorizationId", "oldAppPath", "candidateAppPath", "targetAppPath",
        "oldExecutableSha256", "candidateExecutableSha256", "candidateManifestSha256",
    )
    invalid_fields = [key for key in required_string_fields if not _nonempty_json_string(authorization.get(key))]
    if invalid_fields:
        raise GateBlocked([f"Runtime replacement authorization fields must be non-empty JSON strings: {', '.join(invalid_fields)}"])
    if not _nonempty_json_string(authorization.get("authorizationId")):
        raise GateBlocked(["Runtime replacement authorization ID is missing."])
    if authorization.get("oldExecutableSha256") != expected_old_sha256:
        raise GateBlocked(["Replacement authorization does not match the installed legacy executable hash."])
    if Path(authorization["candidateAppPath"]).resolve(strict=True) != candidate_source.resolve(strict=True):
        raise GateBlocked(["Replacement authorization does not name this exact candidate app path."])
    if Path(authorization["targetAppPath"]).resolve(strict=False) != normal_app_path.resolve(strict=False):
        raise GateBlocked(["Replacement authorization does not name this exact Production install path."])
    if Path(authorization["oldAppPath"]).resolve(strict=True) != old_app.resolve(strict=True):
        raise GateBlocked(["Replacement authorization does not name this exact installed legacy app path."])
    if running_processes:
        raise GateBlocked(["A Production runtime process is still running; retirement cannot start."])
    old = read_bundle(old_app)
    if old["bundle_id"] != PRODUCTION_BUNDLE_ID or old["executable_sha256"] != expected_old_sha256:
        raise GateBlocked(["Installed app does not match the recorded legacy Production runtime."])
    if normal_app_path.resolve() != old_app.resolve() or not old_app.exists():
        raise GateBlocked(["Legacy runtime path is not the expected Production install path."])
    if len(production_app_inventory) != 1 or production_app_inventory[0].get("bundle_path") != str(old_app.resolve()):
        raise GateBlocked(["Normal app locations contain unknown or duplicate Production app copies."])
    candidate = read_bundle(candidate_source)
    candidate_errors = validate_manifest(candidate)
    if candidate_errors:
        raise GateBlocked(candidate_errors)
    if candidate["bundle_id"] != PRODUCTION_BUNDLE_ID:
        raise GateBlocked(["Candidate bundle ID is not the Production identity."])
    if candidate["executable_sha256"] != authorization.get("candidateExecutableSha256"):
        raise GateBlocked(["Candidate hash does not match the replacement authorization."])
    approved_manifest_hash = authorization.get("candidateManifestSha256")
    if not approved_manifest_hash or candidate.get("manifest_sha256") != approved_manifest_hash:
        raise GateBlocked(["Candidate manifest bytes do not match the replacement authorization."])
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + secrets.token_hex(4)
    archive_dir = archive_root / f"legacy-v3-{timestamp}"
    archive_app = archive_dir / (APP_NAME + ".retired")
    candidate_stage = normal_app_path.with_name(normal_app_path.name + ".v4-staging")
    archive_dir.mkdir(parents=True, exist_ok=False)
    original_files = file_inventory(old_app)
    shutil.copytree(old_app, archive_app, symlinks=True)
    if file_inventory(archive_app) != original_files:
        shutil.rmtree(archive_dir, ignore_errors=True)
        raise GateBlocked(["Archived legacy app does not byte-match the installed source."])
    archive_executable = archive_app / "Contents/MacOS" / old["executable_name"]
    original_mode = stat.S_IMODE(archive_executable.stat().st_mode)
    archive_executable.chmod(original_mode & ~0o111)
    if archive_executable.stat().st_mode & 0o111:
        raise GateBlocked(["Archived legacy executable remains launchable."])
    receipt = {
        "status": "LEGACY_RUNTIME_ARCHIVED_AND_DISABLED",
        "observedAtUtc": datetime.now(timezone.utc).isoformat(),
        "authorizationId": authorization["authorizationId"],
        "originalBundlePath": str(old_app),
        "archivePath": str(archive_app),
        "legacyExecutableSha256": old["executable_sha256"],
        "archiveExecutableOriginalMode": original_mode,
        "archiveFileInventory": original_files,
        "candidateExecutableSha256": candidate["executable_sha256"],
        "candidateManifestSha256": candidate["manifest_sha256"],
        "productionAppInventory": production_app_inventory,
        "processInventory": {"complete": True, "processes": running_processes},
    }
    receipt_path = archive_dir / "retirement-receipt.json"
    _persist_receipt(receipt_path, receipt, create=True)

    try:
        shutil.rmtree(old_app)
        shutil.copytree(candidate_source, candidate_stage, symlinks=True)
        staged = read_bundle(candidate_stage)
        if staged["executable_sha256"] != candidate["executable_sha256"] or staged["manifest_sha256"] != approved_manifest_hash:
            raise GateBlocked(["Staged candidate executable or manifest bytes differ from the approved source."])
        os.replace(candidate_stage, normal_app_path)
        installed = read_bundle(normal_app_path)
        errors = validate_manifest(installed)
        expected_installed_executable = normal_app_path.resolve(strict=True) / "Contents/MacOS" / EXECUTABLE_NAME
        installed_executable = Path(installed["executable_path"]).resolve(strict=True)
        if errors or installed["bundle_id"] != PRODUCTION_BUNDLE_ID or installed["executable_name"] != EXECUTABLE_NAME or installed_executable != expected_installed_executable or installed["executable_sha256"] != candidate["executable_sha256"] or installed["manifest_sha256"] != approved_manifest_hash:
            raise GateBlocked(errors or ["Installed Production candidate executable or manifest bytes differ from the approved candidate."])
        receipt["status"] = "CANDIDATE_INSTALLED_AND_VERIFIED"
        receipt["installedBundleId"] = installed["bundle_id"]
        receipt["installedExecutablePath"] = installed["executable_path"]
        receipt["installedExecutableSha256"] = installed["executable_sha256"]
        receipt["installedManifestSha256"] = installed["manifest_sha256"]
        _persist_receipt(receipt_path, receipt, create=False)
        return receipt
    except Exception as failure:
        rollback_errors: list[str] = []
        try:
            if candidate_stage.exists():
                shutil.rmtree(candidate_stage)
            if normal_app_path.exists():
                shutil.rmtree(normal_app_path)
            shutil.copytree(archive_app, normal_app_path, symlinks=True)
            restored_executable = normal_app_path / "Contents/MacOS" / old["executable_name"]
            restored_executable.chmod(original_mode)
            restored = read_bundle(normal_app_path)
            if restored["executable_sha256"] != old["executable_sha256"] or restored["bundle_id"] != PRODUCTION_BUNDLE_ID or restored["executable_name"] != old["executable_name"]:
                raise ValueError("restored old app identity/hash verification failed")
            if stat.S_IMODE(restored_executable.stat().st_mode) != original_mode:
                raise ValueError("restored old app executable mode verification failed")
            receipt["status"] = "ROLLBACK_COMPLETED"
            receipt["rollbackExecutableSha256"] = restored["executable_sha256"]
            receipt["rollbackExecutableMode"] = stat.S_IMODE(restored_executable.stat().st_mode)
        except Exception as rollback_error:
            rollback_errors.append(f"{type(rollback_error).__name__}: {rollback_error}")
            receipt["status"] = "ROLLBACK_FAILED"
            receipt["rollbackErrors"] = rollback_errors
        receipt["failure"] = f"{type(failure).__name__}: {failure}"
        receipt["recoveryArchivePath"] = str(archive_app)
        _persist_receipt(receipt_path, receipt, create=False)
        if receipt["status"] == "ROLLBACK_FAILED":
            raise GateBlocked(["Runtime replacement failed and rollback failed; archived recovery evidence remains at " + str(archive_app), *rollback_errors]) from failure
        raise GateBlocked([f"Runtime replacement failed; old app was restored from {archive_app}: {failure}"]) from failure


def run_retirement(candidate_path: Path, authorization_path: Path) -> dict[str, Any]:
    _require_legacy_fixture_path(APP_DATA)
    if sys.platform != "darwin":
        raise GateBlocked(["Production runtime retirement is supported only on macOS."])
    observed: dict[str, Any] = {
        "status": "PRECHECK_BLOCKED",
        "observedAtUtc": datetime.now(timezone.utc).isoformat(),
        "candidatePath": str(candidate_path),
        "oldAppPath": str(APP_PATH),
        "destructiveActionPerformed": False,
        "appInventoryComplete": False,
        "productionAppInventory": None,
        "processInventory": {"complete": False, "processes": None},
    }
    try:
        authorization = _load_json(authorization_path, "Runtime replacement authorization")
        installed_apps = inventory_production_apps([Path("/Applications"), Path.home() / "Applications"])
        observed["appInventoryComplete"] = True
        observed["productionAppInventory"] = installed_apps
        process_inventory = inventory_production_processes(known_apps=installed_apps)
        observed["processInventory"] = process_inventory
        if process_inventory.get("complete") is not True or not isinstance(process_inventory.get("processes"), list):
            raise GateBlocked(process_inventory.get("diagnostics") or ["Process inventory is incomplete or unknown."])
        processes = process_inventory["processes"]
    except Exception as error:
        observed["exceptionCategory"] = type(error).__name__
        observed["exceptionMessage"] = str(error)
        observed["destructiveActionPerformed"] = False
        receipt_path = APP_DATA / "runtime-replacement-receipts" / f"precheck-blocked-{int(time.time())}-{secrets.token_hex(4)}.json"
        try:
            _persist_receipt(receipt_path, observed, create=True)
        except Exception as persist_error:
            raise GateBlocked([f"Precheck failed: {type(error).__name__}: {error}", f"PRECHECK_BLOCKED receipt could not be persisted: {type(persist_error).__name__}: {persist_error}"]) from error
        reasons = error.reasons if isinstance(error, GateBlocked) else [f"{type(error).__name__}: {error}"]
        raise GateBlocked([*reasons, f"Precheck receipt: {receipt_path}"]) from error
    archive_root = APP_DATA / "retired-production-runtimes"
    receipts_before = set(archive_root.glob("*/retirement-receipt.json")) if archive_root.exists() else set()
    try:
        return retirement_replace(
            APP_PATH,
            candidate_path,
            APP_PATH,
            archive_root,
            authorization,
            processes,
            installed_apps,
        )
    except Exception as error:
        existing_receipts = [item for item in (archive_root.glob("*/retirement-receipt.json") if archive_root.exists() else []) if item not in receipts_before]
        prior_receipts: list[tuple[Path, dict[str, Any]]] = []
        for item in existing_receipts:
            try:
                prior_receipts.append((item, json.loads(item.read_text(encoding="utf-8"))))
            except (OSError, json.JSONDecodeError):
                continue
        final_receipts = [(path, receipt) for path, receipt in prior_receipts if receipt.get("status") in {"CANDIDATE_INSTALLED_AND_VERIFIED", "ROLLBACK_COMPLETED", "ROLLBACK_FAILED"}]
        if final_receipts:
            if isinstance(error, GateBlocked):
                raise
            raise GateBlocked([f"Runtime replacement failed: {type(error).__name__}: {error}"]) from error
        if prior_receipts:
            path, receipt = max(prior_receipts, key=lambda item: item[0].stat().st_mtime)
            raise GateBlocked([f"Runtime replacement outcome is incomplete; inspect persisted receipt {path} (status={receipt.get('status')})."]) from error
        if not prior_receipts:
            observed["status"] = "PRECHECK_BLOCKED"
            observed["exceptionCategory"] = type(error).__name__
            observed["exceptionMessage"] = str(error)
            observed["destructiveActionPerformed"] = False
            receipt_path = APP_DATA / "runtime-replacement-receipts" / f"precheck-blocked-{int(time.time())}-{secrets.token_hex(4)}.json"
            try:
                _persist_receipt(receipt_path, observed, create=True)
            except Exception as persist_error:
                raise GateBlocked([f"Precheck failed: {type(error).__name__}: {error}", f"PRECHECK_BLOCKED receipt could not be persisted: {type(persist_error).__name__}: {persist_error}"]) from error
            reasons = error.reasons if isinstance(error, GateBlocked) else [f"{type(error).__name__}: {error}"]
            raise GateBlocked([*reasons, f"Precheck receipt: {receipt_path}"]) from error


def create_synthetic_rehearsal(fixture_root: Path) -> dict[str, Any]:
    root = fixture_root.resolve()
    protected = [Path("/Applications").resolve(), APP_DATA.resolve()]
    if any(root == item or item in root.parents or root in item.parents for item in protected):
        raise GateBlocked(["Synthetic rehearsal root overlaps a protected real Production path."])
    if root.exists() and any(root.iterdir()):
        raise GateBlocked(["Synthetic rehearsal requires an empty isolated fixture directory."])
    app_data = root / "Library/Application Support" / PRODUCTION_BUNDLE_ID
    app_path = root / "Applications" / APP_NAME
    executable = app_path / "Contents/MacOS" / EXECUTABLE_NAME
    executable.parent.mkdir(parents=True, exist_ok=True)
    executable.write_bytes(b"synthetic-approved-v4-runtime")
    executable.chmod(0o755)
    with (app_path / "Contents/Info.plist").open("wb") as stream:
        plistlib.dump({"CFBundleIdentifier": PRODUCTION_BUNDLE_ID, "CFBundleExecutable": EXECUTABLE_NAME, "CFBundleShortVersionString": "fixture"}, stream)
    manifest = {
        "manifestFormatVersion": 1,
        "runtimeGeneration": 4,
        "minSupportedSchemaVersion": 1,
        "maxSupportedSchemaVersion": 4,
        "bundleId": PRODUCTION_BUNDLE_ID,
        "executable": f"Contents/MacOS/{EXECUTABLE_NAME}",
    }
    manifest_path = app_path / MANIFEST_RELATIVE_PATH
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False), encoding="utf-8")
    database_path = app_data / DATABASE_NAME
    database_path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(database_path) as connection:
        connection.executescript(
            "CREATE TABLE profiles(id TEXT PRIMARY KEY);"
            "CREATE TABLE schema_migrations(version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL);"
            "INSERT INTO schema_migrations VALUES(1,'fixture'),(2,'fixture'),(3,'fixture');"
            "PRAGMA user_version=3;"
        )
    backup_path = app_data / "production-v4-backups" / DATABASE_NAME
    backup_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(database_path, backup_path)
    candidate = read_bundle(app_path)
    database = inspect_database(database_path)
    backup = {"path": str(backup_path.resolve()), "exists": True, "sha256": sha256_file(backup_path)}
    migration_authorization = {
        "status": "OWNER_AUTHORIZED_PRODUCTION_V4_MIGRATION",
        "authorizationId": "synthetic-chain-authorization-1",
        "productionDbPreMigrationSha256": database["sha256"],
        "candidateExecutableSha256": candidate["executable_sha256"],
        "backupPath": str(backup_path.resolve()),
    }
    facts = {
        "platform": "darwin",
        "expected_installed_app": str(app_path.resolve()),
        "expected_database_path": str(database_path.resolve()),
        "running_production_processes": [],
        "process_inventory": {"complete": True, "processes": []},
        "process_inventory_complete": True,
        "app_inventory_complete": True,
        "sidecars_absent": True,
        "production_apps": [candidate],
        "candidate": candidate,
        "candidate_approval": {
            "status": "OWNER_APPROVED_V4_PRODUCTION_CANDIDATE",
            "authorizationId": "synthetic-candidate-approval-1",
            "candidateExecutableSha256": candidate["executable_sha256"],
            "compatibilityManifestSha256": candidate["manifest_sha256"],
            "bundleId": PRODUCTION_BUNDLE_ID,
            "maxSupportedSchemaVersion": 4,
        },
        "migration_authorization": migration_authorization,
        "production_database": database,
        "backup": backup,
    }
    receipt = make_release_receipt(facts, synthetic_fixture_root=root)
    receipt_path = root / "evidence" / "preflight-receipt.json"
    _persist_receipt(receipt_path, receipt, create=True)
    permit_path = app_data / PRODUCTION_MIGRATION_AUTHORIZATION
    write_migration_permit(receipt, migration_authorization, permit_path)
    return {
        "status": "SYNTHETIC_PREFLIGHT_AND_PERMIT_CREATED",
        "fixtureRoot": str(root),
        "appData": str(app_data),
        "appPath": str(app_path),
        "executablePath": str(executable),
        "databasePath": str(database_path),
        "backupPath": str(backup_path),
        "receiptPath": str(receipt_path),
        "permitPath": str(permit_path),
        "candidateExecutableSha256": candidate["executable_sha256"],
        "manifestSha256": candidate["manifest_sha256"],
        "databaseSha256": database["sha256"],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    for name in ("preflight", "migrate"):
        subparser = subparsers.add_parser(name)
        subparser.add_argument("--candidate-approval", type=Path, required=True)
        subparser.add_argument("--migration-authorization", type=Path, required=True)
        subparser.add_argument("--receipt", type=Path, help="fixed gate receipt path; overrides are rejected")
        subparser.add_argument("--synthetic-root", type=Path, help="explicit, marked temporary namespace for isolated integration")
        subparser.add_argument("--synthetic-mode", choices=("legacy-component", "unified-r2b"), default="legacy-component")
    recover = subparsers.add_parser("recover-diagnostic", help="read-only unified R2B recovery disposition; Production is refused")
    recover.add_argument("--domain", choices=("UNIFIED_R2B_SYNTHETIC", "PRODUCTION"), required=True)
    recover.add_argument("--root", type=Path, required=True)
    recover.add_argument("--recovery-authorization", type=Path, required=True)
    recover.add_argument("--authorization-sha256", required=True,
                         help="independently pinned exact-byte SHA-256 of the supplied synthetic recovery authorization")
    retire = subparsers.add_parser("retire")
    retire.add_argument("--candidate-app", type=Path, required=True)
    retire.add_argument("--replacement-authorization", type=Path, required=True)
    args = parser.parse_args()
    try:
        if args.command == "retire":
            # Historical helpers remain available for their isolated regression
            # fixtures, but the supported Production CLI must not use the
            # superseded split-connection/runtime-restoration contract.
            raise GateBlocked(["Runtime retirement remains a separate, explicitly authorized operation and is not this migration command."])
        if args.command == "recover-diagnostic":
            from unified_r2b_recovery import AUTH_DOMAIN, diagnose
            if args.domain != AUTH_DOMAIN:
                raise GateBlocked(["Production recovery diagnostic is not authorized; only marked synthetic roots are supported."])
            result = diagnose(args.root, args.recovery_authorization, args.authorization_sha256, domain=args.domain)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        receipt_path = args.receipt
        if args.synthetic_root is not None:
            unified = args.synthetic_mode == "unified-r2b"
            root = _validate_synthetic_gate_root(args.synthetic_root, unified_r2b=unified)
            expected_receipt = root / "release-receipt.json" if unified else root / "Library" / "Application Support" / PRODUCTION_BUNDLE_ID / PRODUCTION_RELEASE_RECEIPT
            if receipt_path is not None and receipt_path.resolve(strict=False) != expected_receipt.resolve(strict=False):
                raise GateBlocked(["Synthetic receipt path is fixed inside the marked synthetic root."])
            receipt_path = expected_receipt
        elif receipt_path is not None and receipt_path.resolve(strict=False) != RELEASE_RECEIPT_PATH.resolve(strict=False):
            raise GateBlocked(["Production release receipt path is fixed by the Production identity contract."])
        result = run_gate(args.command, args.candidate_approval, args.migration_authorization,
                          receipt_path, synthetic_fixture_root=args.synthetic_root, synthetic_mode=args.synthetic_mode)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except Exception as error:
        reasons = error.reasons if isinstance(error, GateBlocked) else [f"{type(error).__name__}: {error}"]
        if args.command == "recover-diagnostic":
            refusal = {"status": "REFUSE", "currentState": "UNVERIFIED",
                       "recoveryDisposition": "REFUSE", "businessAccessDecision": "REFUSE",
                       "businessAccessAllowed": False, "migrationMayRerun": False,
                       "oldPermitReusable": False, "newAuthorizationRequired": True,
                       "restoreAllowed": False, "readonlyConfirmationAllowed": False,
                       "automaticRecovery": False, "diagnosticMutationCount": 0,
                       "reasons": reasons}
            print(json.dumps(refusal, ensure_ascii=False), file=sys.stderr)
            return 2
        print(json.dumps({"status": "BLOCKED", "errorType": type(error).__name__, "reasons": reasons}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
